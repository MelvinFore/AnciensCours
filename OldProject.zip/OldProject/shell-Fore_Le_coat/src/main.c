/*
  Projet minishell - Licence 3 Info - PSI 2022

  Nom :Fore/Le coat
  Prénom :Melvin/Frederic
  Num. étudiant :22011371/21803360
  Groupe de projet :Binôme 2
  Date :23/12/2022

  Interface du minishell.

 */

#include <stdio.h>
#include <stdlib.h>
#include "parser.h"
#include "processus.h"
#include <string.h>


int main() {
  char cmdline[MAX_LINE_SIZE]; // buffer des lignes de commandes
  char* cmdtoks[MAX_CMD_SIZE]; // "mots" de la ligne de commandes
  processus_t processes[MAX_CMD_SIZE];
  processus_t* current;
  int etatexec;
  int next;
  int cont=0;
  char messexc[200];

  strcpy(messexc,"commande invalide\n");
  while (1 && cont==0) {
    for(int i=0;i<MAX_LINE_SIZE;i++)
      cmdline[i]='\0';

    for(int i=0;i<MAX_CMD_SIZE;i++){
      cmdtoks[i]=malloc(sizeof(char)*MAX_LINE_SIZE);
      for(int j=0;j<MAX_LINE_SIZE;j++)
        cmdtoks[i][j]='\0';
    }

    // Effacer les contenus de cmdline, cmdtoks et processes

    for(int i=0;i<MAX_CMD_SIZE;i++){
      init_process(&processes[i]);
    }


    // Initialiser les valeurs par défaut dans processes (stdin, stdout, stderr, ...)

    // Afficher un prompt
    printf("$ ");

    // Lire une ligne dans cmdline - Attention fgets enregistre le \n final
    if (fgets(cmdline, MAX_LINE_SIZE, stdin)==NULL) break;
    cmdline[strlen(cmdline)-1]='\0';

    // Traiter la ligne de commande
    //   - supprimer les espaces en début et en fin de ligne
    trim(cmdline);
    //   - ajouter d'éventuels espaces autour de ; ! || && & ...
    separate_s(cmdline, "; ! | & || && > < << >> 2> 2>> &> &>>", MAX_LINE_SIZE);
    //   - supprimer les doublons d'espaces
    clean(cmdline);
    //   - traiter les variables d'environnement
    substenv(cmdline, MAX_LINE_SIZE);
    // Découper la ligne dans cmdtoks
    strcut(cmdline, ' ', cmdtoks, MAX_CMD_SIZE);
    /*
    tst=0;
    while(cmdtoks[tst]!=NULL){
      printf("%s\n",cmdtoks[tst]);
      tst++;
    }*/



    // Traduire la ligne en structures processus_t dans processes
    parse_cmd(cmdtoks,&processes[0],MAX_CMD_SIZE);
    // Les commandes sont chaînées en fonction des séparateurs
    //   - next -> exécution inconditionnelle
    //   - next_success -> exécution si la commande précédente réussit
    //   - next_failure -> exécution si la commande précédente échoue

    // Exécuter les commandes dans l'ordre en fonction des opérateurs
    // de flux
    next=1;
   for (current=processes; current!=NULL; ) {
      if(next==1||(next==2&&etatexec!=1)||(next==3&&etatexec==1)){
        if(is_builtin(current->argv[0])==0){
          etatexec=exec_process(current);
          if(etatexec==1){
            write(2,messexc,strlen(messexc));
          }
        }else{
          builtin(current);
          if(current->status==1){
            cont=1;
            break;
          }
        }
      }
        if(current->stdin!=0 && current->stdin!=1 && current->stdin!=2)
        close(current->stdin);
        if(current->stdout!=0 && current->stdout!=1 && current->stdout!=2)
        close(current->stdout);
        if(current->stderr!=0 && current->stderr!=1 && current->stderr!=2)
        close(current->stderr);
      if (current->next!=NULL) {
        next=1;
	      // Exécution inconditionnelle
	      current=current->next;
	      continue;
      }  else if (current->next_success!=NULL) {
	      // Si la commande a réussi
        next=2;
	      current = current->next_success;
	      continue;
      } else if (current->next_failure!=NULL) {
        next=3;
	      // Si la commande a échoué
	      current = current->next_failure;
      }else{
        //dans le cas ou il n'y a plus de commande on met current a null et on sort du fort
        current=NULL;
      }
    }
    for(int i=0;i<MAX_CMD_SIZE;i++)
      free(cmdtoks[i]);
  }

  fprintf(stderr, "\nGood bye!\n");
  return 0;
}
