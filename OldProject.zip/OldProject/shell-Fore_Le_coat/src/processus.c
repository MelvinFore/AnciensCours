/*
  Projet minishell - Licence 3 Info - PSI 2022

  Nom :Fore/Le coat
  Prénom :Melvin/Frederic
  Num. étudiant :22011371/21803360
  Groupe de projet :Binôme 2
  Date :23/12/2022

  Gestion des processus (implémentation).

 */

#include "processus.h"
#include "string.h"
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

//Dans fdclose du processus -1 symbolise la fin du tableau. Donc on parcourt la totalité du tableau et si aucun descripteur ne correspond à celui que l'on souhaite ajouter, on l'ajoute à la fin du tableau
int add_fd(int* fdclose, int fd, int max){
  int id=0;
  while(fdclose[id]!=-1){
    if(fdclose[id]==fd)
      return 0;
    else
      id++;
  }
  fdclose[id]=fd;
  return 0;
}


//merge fd close nous permet entre deux processus de partager les descripteur qui ne sont pas encore commun entre eux
int merge_fdclose(int* tab1, int* tab2){
  int id1=0;
  int id2=0;
  while(tab1[id1]!=-1){
    add_fd(tab2,tab1[id1],MAX_CMD_SIZE);
    id1++;
  }
  while(tab2[id2]!=-1){
    add_fd(tab1,tab2[id2],MAX_CMD_SIZE);
    id2++;
  }
  return 0;
}

int exec_process(processus_t* p) {
  p->pid=fork();
  if(p->pid==0){
    dup2(p->stdin,0);
    dup2(p->stdout,1);
    dup2(p->stderr,2);
    for (int * fd = p->fdclose; *fd != -1; ++fd) {
      close(*fd);
    }
    execvp(p->path,p->argv);
    return 1;
  }else
  waitpid(-1,NULL,0);

}


int init_process(processus_t* p) {
  p->pid=-1;
  p->status=-1;
  p->wait=-1;
  p->path=NULL;
  for(int j=0;j<MAX_CMD_SIZE;j++)
    p->argv[j]=NULL;
  for(int x=0;x<MAX_CMD_SIZE;x++)
    p->fdclose[x]=-1;
p->stdin=0;
p->stdout=1;
p->stderr=2;
p->next=NULL;
p->next_failure=NULL;
p->next_success=NULL;
}

int parse_cmd(char* tokens[], processus_t* p, size_t max) {
int i=0;
int idarg=0;
int idproc=0;
  while(tokens[i]!=NULL){
    if(strcmp(";",tokens[i])==0){
      p[idproc].argv[idarg]=NULL;
      p[idproc].next=&p[idproc+1];
      idproc++;
      i++;
      idarg=0;
    }

    if(strcmp(">",tokens[i])==0){
      i++;
        int fdout=open(tokens[i],O_WRONLY|O_CREAT|O_TRUNC,0644);
        p[idproc].stdout=fdout;
        add_fd(p[idproc].fdclose, fdout, MAX_CMD_SIZE);
        i++;
        continue;
    }

    if(strcmp(">>",tokens[i])==0){
      i++;
        int fdout=open(tokens[i],O_WRONLY|O_CREAT|O_APPEND,0644);
        p[idproc].stdout=fdout;
        add_fd(p[idproc].fdclose, fdout, MAX_CMD_SIZE);
        i++;
        continue;
    }

    if(strcmp("<",tokens[i])==0){
        p[idproc].argv[idarg]=NULL;
        int fdin=open(tokens[i+1],O_RDONLY);
        p[idproc].stdin=fdin;
        add_fd(p[idproc].fdclose, fdin, MAX_CMD_SIZE);
        i++;
        continue;
    }

    if(strcmp("2>",tokens[i])==0){
    i++;
      int fderr=open(tokens[i],O_WRONLY|O_CREAT|O_TRUNC,0644);
      p[idproc].stderr=fderr;
      add_fd(p[idproc].fdclose, fderr, MAX_CMD_SIZE);
      i++;
      continue;
    }

    if(strcmp("2>>",tokens[i])==0){
    i++;
      int fderr=open(tokens[i],O_WRONLY|O_CREAT|O_APPEND,0644);
      p[idproc].stderr=fderr;
      add_fd(p[idproc].fdclose, fderr, MAX_CMD_SIZE);
      i++;
      continue;
    }

    if(strcmp("|",tokens[i])==0){
      pipe(tube);//un seul tube suffit pour faire des pipe multiple avec notre implémentation
      p[idproc].argv[idarg]=NULL;
      p[idproc].stdout=tube[1];
      add_fd(p[idproc].fdclose,tube[1],MAX_CMD_SIZE);
      p[idproc].next=&p[idproc+1];
      idproc++;
      p[idproc].stdin=tube[0];
      add_fd(p[idproc].fdclose,tube[0],MAX_CMD_SIZE);
      i++;
      idarg=0;
    }

    if(strcmp("&&",tokens[i])==0){
      p[idproc].argv[idarg]=NULL;
      p[idproc].next_success=&p[idproc+1];
      idproc++;
      i++;
      idarg=0;
    }
    if(strcmp("||",tokens[i])==0){
      p[idproc].argv[idarg]=NULL;
      p[idproc].next_failure=&p[idproc+1];
      idproc++;
      i++;
      idarg=0;
    }
    if(idarg==0){
      p[idproc].path=tokens[i];
    }
    p[idproc].argv[idarg]=tokens[i];
    idarg++;
    i++;
  }
  p[idproc].argv[idarg]=NULL;
  for(int i=1; i<=idproc;i++){
    merge_fdclose(p[0].fdclose,p[i].fdclose);
  }
  for(int i=1; i<=idproc;i++){
    merge_fdclose(p[0].fdclose,p[i].fdclose);
  }
}
