/*
  Projet minishell - Licence 3 Info - PSI 2022

  Nom :Fore/Le coat
  Prénom :Melvin/Frederic
  Num. étudiant :22011371/21803360
  Groupe de projet :Binôme 2
  Date :23/12/2022

  Parsing de la ligne de commandes utilisateur (implémentation).

 */

#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_LINE_SIZE   1024
#define MAX_CMD_SIZE    256

int trim(char* str) {
  char c[MAX_LINE_SIZE];
  memset(c,'\0',MAX_LINE_SIZE);
  int pos=0;
  int space=0;
  while(str[space]==' ')
    space++;
  for(int i=space; i<strlen(str);i++){
      c[pos]=(char)str[i];
      pos++;
    }
  space=strlen(c)-1;
  while(c[space]==' ')
    space--;
  c[space+1]='\0';
  memcpy(str,c,strlen(str)*sizeof(char));

return 0;
}

int clean(char* str) {
  char c[MAX_LINE_SIZE];
  memset(c,'\0',MAX_LINE_SIZE);
  int pos=0;
  for(int i=0; i<strlen(str);i++){
    if(str[i]!=' '){
      c[pos]=(char)str[i];
      pos++;
    }else{
      while(str[i+1]==' ')
        i++;
        c[pos]=' ';
        pos++;
    }
  }
  c[pos]='\0';
  memcpy(str,c,strlen(str)*sizeof(char));

return 0;
}

int separate_s(char* str, char* s, size_t max) {
  int trouve=0;
  char c[max];
  char sep[MAX_CMD_SIZE][MAX_LINE_SIZE];
  int posl=0;
  int posc=0;
  int posmax=-1;
  for(int i=0;i<strlen(s);i++){
    if(s[i]==' '){
      sep[posl][posc]='\0';
      posc=0;
      posl++;
      i++;
    }
    sep[posl][posc]=s[i];
    posc++;
  }
  sep[posl][posc]='\0';
  posc=0;
  posl++;
  while(posl<MAX_CMD_SIZE){
    sep[posl][0]='\0';posl++;
  }
  posl=0;
  /*while(sep[posl][0]!='\0'){
      printf("%s\n",sep[posl]);
      posl++;
    }*/
  memset(c,'\0',max);
  int pos=0;
  int cpyi;
  posl=0;
  posc=0;
    for(int i=0; i<strlen(str);i++){
    while(sep[posl][0]!='\0'){
      cpyi=i;
      while(sep[posl][posc]==str[cpyi]&&sep[posl][posc]!='\0'){
        posc++;
        cpyi++;
      }
      if(sep[posl][posc]=='\0'){
        trouve=1;
        if(posmax==-1||strlen(sep[posmax])<strlen(sep[posl]))
          posmax=posl;
      }
      posl++;
      posc=0;
      }
      posc=0;
        if(trouve==1){
          c[pos]=' ';
          pos++;
          while(sep[posmax][posc]!='\0'){
          c[pos]=str[i];
          pos++;
          i++;
          posc++;
        }
          i--;
          c[pos]=' ';
          pos++;
        }else{
          c[pos]=str[i];
          pos++;
        }
      if(trouve==1)
      trouve=0;
      posl=0;
      posc=0;
      posmax=-1;
    }
    memcpy(str,c,max);
    return 0;
}

int substenv(char* str, size_t max) {
  char recup[MAX_LINE_SIZE];
  char c[max];
  memset(c,'\0',max);
  memset(recup,'\0',MAX_LINE_SIZE);
  int pos=0;
  int posfinal=0;
  char* sub;
 for(int i=0;i<strlen(str);i++){
    if(str[i]=='$'&&((str[i-1])==' '||(str[i+1])=='{'|| i-1<0)){
      i++;
      if(str[i]=='{')
        i++;
      while(str[i]!=' ' && str[i]!='}'&&str[i]!='$'&&str[i]!='\0'){
        recup[pos]=str[i];
        i++;
        pos++;
      }
        if(str[i]==' '||str[i]=='$'||str[i]=='\0')
          i--;
      recup[pos]='\0';
      if(getenv(recup)!=NULL){
      sub=getenv(recup);
      for(int x=0;x<strlen(sub);x++){
        c[posfinal]=sub[x];
        posfinal++;
      }
      sub=NULL;
    }else{
      if(str[i-strlen(recup)]=='$'){
        c[posfinal]='$';
        posfinal++;
      }
      if(str[i-(strlen(recup)+1)]=='{'||str[i-strlen(recup)]=='{'){
        c[posfinal]='$';
        posfinal++;
        c[posfinal]='{';
        posfinal++;
      }
      for(int x=0;x<strlen(recup);x++){
        c[posfinal]=recup[x];
        posfinal++;
      }
      if(str[i]=='}'){
        c[posfinal]='}';
        posfinal++;
      }
    }
      for(int j=0; j<200-1;j++)
      recup[j]='\0';
      pos=0;
    }else{
      c[posfinal]=str[i];
      posfinal++;
    }
  }
  c[posfinal]='\0';
  memcpy(str,c,max);
  str[max]='\0';
}

int strcut(char* str, char sep, char** tokens, size_t max) {
  char recup[max];
  memset(recup,'\0',max);
  int cpt=0;
  int i=0;
  int pos=0;
    while(cpt<max-1&&str[i]!='\0'){
      if(str[i]==sep||str[i+1]=='\0'){
        if(str[i+1]=='\0'){
                recup[pos]=str[i];
                pos++;
              }
        recup[pos]='\0';
        memcpy(*(tokens+cpt),&recup,strlen(recup));
        i++;
        cpt++;
        pos=0;
        for(int j=0; j<200-1;j++)
        recup[j]='\0';
      }else{
      recup[pos]=str[i];
      pos++;
      i++;
    }
    }
    tokens[cpt]=NULL;
}

// Optionnel
int strcut_s(char* str, char sep, char** tokens, size_t max) {

}
