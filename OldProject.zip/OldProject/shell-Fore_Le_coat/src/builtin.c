/*
  Projet minishell - Licence 3 Info - PSI 2022

  Nom :Fore/Le coat
  Prénom :Melvin/Frederic
  Num. étudiant :22011371/21803360
  Groupe de projet :Binôme 2
  Date :23/12/2022

  Gestion des commandes internes du minishell (implémentation).

 */

#include "processus.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>

int is_builtin(const char* cmd) {
  if((strcmp("export",cmd)==0||strcmp("unset",cmd)==0||strcmp("cd",cmd)==0||strcmp("exit",cmd)==0)){
    return 1;
  }
  return 0;
}

//La commande chdir nous redirige dans un autre repertoire comme la commande cd
int cd(const char* path, int fderr) {
  int err;
  char* mess="le repertoire n'existe pas\n";
  err=chdir(path);
  if(err==-1){
    write(fderr,mess,strlen(mess));
  }
  return 0;
}

int export(const char* var, const char* value, int fderr) {
  int err;
  char* mess="impossible d'initialisé la variable d'environnement\n";
  err=setenv(var,value,0);
  if(err==-1){
    write(fderr,mess,strlen(mess));
  }
  return 0;
}

int unset(const char* var,int fderr){
  int err;
  char* mess="impossible de supprimer la variable d'environnement\n";
  unsetenv(var);
  if(err==-1){
    write(fderr,mess,strlen(mess));
  }
  return 0;
}

int exit_shell(int ret, int fderr) {
  ret=1;
  return ret;
}


int builtin(processus_t* proc) {
if(strcmp("export",proc->argv[0])==0)
  export(proc->argv[1],proc->argv[2],proc->stderr);
if(strcmp("unset",proc->argv[0])==0)
  unset(proc->argv[1],proc->stderr);
if(strcmp("cd",proc->argv[0])==0)
  cd(proc->argv[1],proc->stderr);
if(strcmp("exit",proc->argv[0])==0)
  proc->status=exit_shell(proc->status,proc->stderr);
}
