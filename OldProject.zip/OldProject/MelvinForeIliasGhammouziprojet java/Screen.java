import mypackage.*;
import javax.swing.*;
import java.awt.Component;
import java.awt.Container.*;
import java.awt.Button;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.Dimension;
import javax.swing.JFrame;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import java.lang.Math;
import javax.swing.border.Border;
import javax.imageio.ImageIO;
import java.io.*;
import javax.swing.JComponent;
import java.awt.event.*;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JColorChooser;

public class Screen extends JFrame implements MouseListener, MouseMotionListener{

Color trait=null;
Color fond=null;		
Canvas dessin;
JPanel vide;
JPanel changeformrect;
JPanel changeformcarre;
JPanel changeformcircle;
JPanel changeformellipse;
JPanel changeformtriangle;
JPanel changeformligne;
JPanel changeformpoint;
private int select=-1;
boolean delete=false;
boolean hitmodif=false;
Button buttoneff;
Button buttonmodif;
boolean butpoint=false;
boolean butligne=false;
boolean butrect=false;
boolean butcarre=false;
boolean butellipse=false;
boolean butcercle=false;
boolean buttriangle=false;
int tmpform=-1;


	Screen(){	
		super();
		dessin=new Canvas();
		setTitle("Paint");
		Dimension dim=Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(dim.width,dim.height);
		Icon iconpoint = new ImageIcon("point.png");
		Icon iconligne = new ImageIcon("ligne.jpg");
		Icon iconcarre = new ImageIcon("carre.png");
		Icon iconrect = new ImageIcon("rectangle.png");
		Icon iconcercle = new ImageIcon("cercle.png");
		Icon iconellipse = new ImageIcon("ellipse.png");
		Icon icontriangle = new ImageIcon("triangle.png");
		Border lineborder = BorderFactory.createLineBorder(Color.black, 2);
		Panel fond = new Panel();
		fond.setBackground(Color.white);
		BoxLayout conteneur = new BoxLayout(fond,BoxLayout.Y_AXIS);
		fond.setLayout(conteneur);

		//BANDEAU DE L'ECRAN

 		Box header = new Box(BoxLayout.X_AXIS);
		header.setMaximumSize(new Dimension(Short.MAX_VALUE, 50));
		header.setBorder(lineborder);
		header.add(Box.createHorizontalGlue());
 		Button buttoneff = new Button("EFFACER");
		buttoneff.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(delete==false){
					buttoneff.setBackground(Color.red);
					delete=true;
					butpoint=false;
					butligne=false;
					butrect=false;				
					butcarre=false;
					butellipse=false;
					butcercle=false;
					buttriangle=false;
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					buttoneff.setBackground(Color.white);
					delete=false;
					}
				}
			}
		);
		buttoneff.setBackground(Color.white);
		buttoneff.setMaximumSize(new Dimension(80,Short.MAX_VALUE));
 		header.add(buttoneff);
		header.add(Box.createHorizontalGlue());

		//BOUTON DE LANCEMENT DU FORMULAIRE

 		buttonmodif= new Button("MODIF FORM");
		buttonmodif.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(hitmodif==false){
						buttonmodif.setBackground(Color.cyan);
						hitmodif=true;
						butpoint=false;
						butligne=false;
						butrect=false;				
						butcarre=false;
						butellipse=false;
						butcercle=false;
						buttriangle=false;
						buttoneff.setBackground(Color.white);
						delete=false;
					        trait=null;
					}else{
						buttonmodif.setBackground(Color.white);
						hitmodif=false;
						changeformrect.setVisible(false);
					        changeformcarre.setVisible(false);
						changeformcircle.setVisible(false);
						changeformtriangle.setVisible(false);
						changeformligne.setVisible(false);
						changeformellipse.setVisible(false);
					}
			}
		}
		);
		buttonmodif.setBackground(Color.white);
		buttonmodif.setMaximumSize(new Dimension(80,Short.MAX_VALUE));
 		header.add(buttonmodif);
		header.add(Box.createHorizontalGlue());

		//BOUTON DE SAUVEGARDE

		JTextField filename = new JTextField();
		filename.setMaximumSize(new Dimension(80000,Short.MAX_VALUE));
		header.add(filename);
		Button button = new Button("ENREGISTRER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
                Save masave= new Save(); 
				masave.stockage(dessin.liste, filename.getText());
				filename.setText("");
				}
			}
		);

		button.setBackground(Color.white);
		button.setMaximumSize(new Dimension(90,Short.MAX_VALUE));
 		header.add(button);


		header.add(Box.createHorizontalGlue());
 		button = new Button("CHARGER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				buttonmodif.setBackground(Color.white);
				hitmodif=false;
				buttoneff.setBackground(Color.white);
				delete=false;
				changeformrect.setVisible(false);
				changeformcarre.setVisible(false);
				changeformcircle.setVisible(false);
				changeformtriangle.setVisible(false);
				changeformligne.setVisible(false);
				changeformellipse.setVisible(false);
				trait=null;
				Chooser selecteur= new Chooser();
				System.out.println("Dans le main"+selecteur.path);
				Load rech= new Load();
				dessin.liste=rech.destockage(selecteur.path);
				dessin.repaint();
				}
			}
		);
		button.setBackground(Color.white);
		button.setMaximumSize(new Dimension(80,Short.MAX_VALUE));
 		header.add(button);
		header.add(Box.createHorizontalGlue());
		header.add(Box.createRigidArea(new Dimension(600,0)));

		//SELECTEUR DE FORME GEO

		Box selecteurpan=new Box(BoxLayout.Y_AXIS);
		Box selecteurlist1=new Box(BoxLayout.X_AXIS);
 		JButton imgbutton = new JButton(iconpoint);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butpoint==false){
					butpoint=true;
					butligne=false;
					butrect=false;				
					butcarre=false;
					butellipse=false;
					butcercle=false;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butpoint=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist1.add(imgbutton);	
 		imgbutton = new JButton(iconligne);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butligne==false){
					butpoint=false;
					butligne=true;
					butrect=false;				
					butcarre=false;
					butellipse=false;
					butcercle=false;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butligne=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
		selecteurlist1.add(imgbutton);	
 		imgbutton = new JButton(iconrect);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butrect==false){
					butpoint=false;
					butligne=false;
					butrect=true;				
					butcarre=false;
					butellipse=false;
					butcercle=false;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butrect=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist1.add(imgbutton);	
 		imgbutton = new JButton(iconcarre);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butcarre==false){
					butpoint=false;
					butligne=false;
					butrect=false;				
					butcarre=true;
					butellipse=false;
					butcercle=false;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butcarre=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist1.add(imgbutton);		
		selecteurpan.add(selecteurlist1);		
		Box selecteurlist2=new Box(BoxLayout.X_AXIS);
 		imgbutton = new JButton(iconellipse);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butellipse==false){
					butpoint=false;
					butligne=false;
					butrect=false;				
					butcarre=false;
					butellipse=true;
					butcercle=false;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butellipse=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist2.add(imgbutton);	
 		imgbutton = new JButton(iconcercle);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(butcercle==false){
					butpoint=false;
					butligne=false;
					butrect=false;				
					butcarre=false;
					butellipse=false;
					butcercle=true;
					buttriangle=false;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					butcercle=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist2.add(imgbutton);
 		imgbutton = new JButton(icontriangle);
		imgbutton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if(buttriangle==false){
					butpoint=false;
					butligne=false;
					butrect=false;				
					butcarre=false;
					butellipse=false;
					butcercle=false;
					buttriangle=true;
					delete=false;
					buttoneff.setBackground(Color.white);
					hitmodif=false;
					buttonmodif.setBackground(Color.white);
					changeformrect.setVisible(false);
					changeformcarre.setVisible(false);
					changeformcircle.setVisible(false);
					changeformtriangle.setVisible(false);
					changeformligne.setVisible(false);
					changeformellipse.setVisible(false);
					trait=null;
					}else{
					buttriangle=false;					
					}
				}
			}
		);
		imgbutton.setBackground(Color.white);
 		selecteurlist2.add(imgbutton);
		selecteurpan.add(selecteurlist2);	
		header.add(selecteurpan);		
 		fond.add(header);

		//CORPS DE L'ECRAN

		Box body= new Box(BoxLayout.X_AXIS);

		//DEBUT FORMULAIRE
		//Forme Rectangle
		changeformrect=new JPanel();
		Box dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformrect.setBorder(lineborder);
		changeformrect.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		JLabel text = new JLabel("Largeur:");
		dispositionformulaire.add(text);
		JTextField largrec = new JTextField(10);
		largrec.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        			if ( ((c < '0') || (c > '9'))) {
        				e.consume();
        				}
     			}
		});
		dispositionformulaire.add(largrec);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("Longueur:");
		dispositionformulaire.add(text);
		JTextField longrec = new JTextField(10);
		longrec.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(longrec);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseurrec = new JTextField(10);
		epaisseurrec.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseurrec);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((longrec.getText().length()!=0||largrec.getText().length()!=0)|| trait!=null || epaisseurrec.getText().length()!=0){					
						if((longrec.getText().length()==0||largrec.getText().length()==0)&& trait!=null && epaisseurrec.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((longrec.getText().length()==0||largrec.getText().length()==0)&& trait==null && epaisseurrec.getText().length()!=0){
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurrec.getText()));
						}else if((longrec.getText().length()==0||largrec.getText().length()==0)&& trait!=null && epaisseurrec.getText().length()!=0){
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurrec.getText()));							
						}else{	
							int longeurrect=Integer.parseInt(longrec.getText());
							int largeurrect=Integer.parseInt(largrec.getText());
							int tmpx=dessin.liste.get(tmpform).posx;
							int tmpy=dessin.liste.get(tmpform).posy;
								if(trait!=null &&  epaisseurrec.getText().length()==0)
									dessin.liste.add(new Rectangle(tmpx,tmpy,longeurrect,largeurrect,trait,dessin.liste.get(tmpform).epaisseur));
								else if(trait==null &&  epaisseurrec.getText().length()!=0)
									dessin.liste.add(new Rectangle(tmpx,tmpy,longeurrect,largeurrect,dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseurrec.getText())));	
								else if(trait==null &&  epaisseurrec.getText().length()==0)
									dessin.liste.add(new Rectangle(tmpx,tmpy,longeurrect,largeurrect,dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));
								else
									dessin.liste.add(new Rectangle(tmpx,tmpy,longeurrect,largeurrect,trait,(float)Integer.parseInt(epaisseurrec.getText())));
								
									dessin.liste.remove(dessin.liste.get(tmpform));
							}
						}	
				dessin.repaint();
				changeformrect.setVisible(false);
				trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformrect.setVisible(false);
		changeformrect.add(dispositionformulaire);
		body.add(changeformrect);

		//Forme carre
		changeformcarre=new JPanel();
		dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformcarre.setBorder(lineborder);
		changeformcarre.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("taillecote:");
		dispositionformulaire.add(text);
		JTextField taillecote = new JTextField(10);
		taillecote.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        			if ( ((c < '0') || (c > '9'))) {
        				e.consume();
        				}
     			}
		});
		dispositionformulaire.add(taillecote);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
				text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseurcarre = new JTextField(10);
		epaisseurcarre.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseurcarre);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((taillecote.getText().length()!=0)|| trait!=null || epaisseurcarre.getText().length()!=0){	
						if((taillecote.getText().length()==0)&&trait!=null&&epaisseurcarre.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((taillecote.getText().length()==0)&&trait==null&&epaisseurcarre.getText().length()!=0){	
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurcarre.getText()));
						}else if((taillecote.getText().length()==0)&&trait!=null&&epaisseurcarre.getText().length()!=0){
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurcarre.getText()));
						}else{
							int longcote=Integer.parseInt(taillecote.getText());
							int tmpx=dessin.liste.get(tmpform).posx;
							int tmpy=dessin.liste.get(tmpform).posy;
							if(trait!=null && epaisseurcarre.getText().length()==0 )
								dessin.liste.add(new Carre(tmpx,tmpy,longcote,trait,dessin.liste.get(tmpform).epaisseur));
							else if(trait==null && epaisseurcarre.getText().length()!=0)
								dessin.liste.add(new Carre(tmpx,tmpy,longcote,dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseurcarre.getText())));
							else if(trait==null && epaisseurcarre.getText().length()==0 )	
								dessin.liste.add(new Carre(tmpx,tmpy,longcote,dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));
							else
								dessin.liste.add(new Carre(tmpx,tmpy,longcote,trait,(float)Integer.parseInt(epaisseurcarre.getText())));	
							dessin.liste.remove(dessin.liste.get(tmpform));
						}
					}	
					dessin.repaint();
					changeformcarre.setVisible(false);
					trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformcarre.setVisible(false);
		changeformcarre.add(dispositionformulaire);
		body.add(changeformcarre);


		//Forme cercle


		changeformcircle=new JPanel();
		dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformcircle.setBorder(lineborder);
		changeformcircle.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("rayon:");
		dispositionformulaire.add(text);
		JTextField rayon = new JTextField(10);
		rayon.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        			if ( ((c < '0') || (c > '9'))) {
        				e.consume();
        				}
     			}	
		});
		dispositionformulaire.add(rayon);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseurcercle = new JTextField(10);
		epaisseurcercle.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseurcercle);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((rayon.getText().length()!=0)|| trait!=null || epaisseurcercle.getText().length()!=0){
						if((rayon.getText().length()==0)&&trait!=null&&epaisseurcercle.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((rayon.getText().length()==0)&&trait==null&&epaisseurcercle.getText().length()!=0){	
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurcercle.getText()));						
						}else if((rayon.getText().length()==0)&&trait!=null&&epaisseurcercle.getText().length()!=0){	
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurcercle.getText()));
						}else{
							int lrayon=Integer.parseInt(rayon.getText());
							int tmpx=dessin.liste.get(tmpform).posx;
							int tmpy=dessin.liste.get(tmpform).posy;
								if(trait!=null && epaisseurcercle.getText().length()==0)
								dessin.liste.add(new Cercle(lrayon,tmpx,tmpy,trait,dessin.liste.get(tmpform).epaisseur));					
								else if(trait==null && epaisseurcercle.getText().length()!=0)
								dessin.liste.add(new Cercle(lrayon,tmpx,tmpy,dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseurcercle.getText())));	
								else if(trait==null && epaisseurcercle.getText().length()==0)
								dessin.liste.add(new Cercle(lrayon,tmpx,tmpy,dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));		
								else	
								dessin.liste.add(new Cercle(lrayon,tmpx,tmpy,trait,(float)Integer.parseInt(epaisseurcercle.getText())));
							dessin.liste.remove(dessin.liste.get(tmpform));
						}
					}	
					dessin.repaint();
					changeformcircle.setVisible(false);
					trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformcircle.setVisible(false);
		changeformcircle.add(dispositionformulaire);
		body.add(changeformcircle);


		//Forme ellipse

		changeformellipse=new JPanel();
		dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformellipse.setBorder(lineborder);
		changeformellipse.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("demi axe a:");
		dispositionformulaire.add(text);
		JTextField demia = new JTextField(10);
		demia.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(demia);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("demi axe b:");
		dispositionformulaire.add(text);
		JTextField demib = new JTextField(10);
		demib.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(demib);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseurellipse = new JTextField(10);
		epaisseurellipse.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseurellipse);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((demia.getText().length()!=0||demib.getText().length()!=0)|| trait!=null || epaisseurellipse.getText().length()!=0){
						if((demia.getText().length()==0||demib.getText().length()==0)&&trait!=null&&epaisseurellipse.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((demia.getText().length()==0||demib.getText().length()==0)&&trait==null&&epaisseurellipse.getText().length()!=0){
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurellipse.getText()));							
						}else if((demia.getText().length()==0||demib.getText().length()==0)&&trait!=null&&epaisseurellipse.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurellipse.getText()));
						}else{
							int axea=Integer.parseInt(demia.getText());
							int axeb=Integer.parseInt(demib.getText());
							int tmpx=dessin.liste.get(tmpform).posx;
							int tmpy=dessin.liste.get(tmpform).posy;
								if(trait!=null && epaisseurellipse.getText().length()==0)
									dessin.liste.add(new Ellipse(axea,axeb,tmpx,tmpy,trait,dessin.liste.get(tmpform).epaisseur));									
								else if(trait==null && epaisseurellipse.getText().length()!=0)
									dessin.liste.add(new Ellipse(axea,axeb,tmpx,tmpy,dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseurellipse.getText())));							
								else if(trait==null && epaisseurellipse.getText().length()==0)
									dessin.liste.add(new Ellipse(axea,axeb,tmpx,tmpy,dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));
								else
									dessin.liste.add(new Ellipse(axea,axeb,tmpx,tmpy,trait,(float)Integer.parseInt(epaisseurellipse.getText())));
								
								dessin.liste.remove(dessin.liste.get(tmpform));
						}
				}	
					dessin.repaint();
					changeformellipse.setVisible(false);
					trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformellipse.setVisible(false);
		changeformellipse.add(dispositionformulaire);
		body.add(changeformellipse);


		//Forme triangle
		changeformtriangle=new JPanel();
		dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformtriangle.setBorder(lineborder);
		changeformtriangle.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("posx point 1:");
		dispositionformulaire.add(text);
		JTextField px1 = new JTextField(10);
		px1.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(px1);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posy point 1:");
		dispositionformulaire.add(text);
		JTextField py1 = new JTextField(10);
		py1.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(py1);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posx point 2:");
		dispositionformulaire.add(text);
		JTextField px2 = new JTextField(10);
		px2.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(px2);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posy point 2:");
		dispositionformulaire.add(text);
		JTextField py2 = new JTextField(10);
		py2.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        			if ( ((c < '0') || (c > '9'))) {
        				e.consume();
        			}
     			}
		});
		dispositionformulaire.add(py2);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posx point 3:");
		dispositionformulaire.add(text);
		JTextField px3 = new JTextField(10);
		px3.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        			if ( ((c < '0') || (c > '9'))) {
        				e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(px3);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posy point 3:");
		dispositionformulaire.add(text);
		JTextField py3 = new JTextField(10);
		py3.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(py3);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseurtriangle = new JTextField(10);
		epaisseurtriangle.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseurtriangle);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((px1.getText().length()!=0||py1.getText().length()!=0 ||px2.getText().length()!=0||py2.getText().length()!=0||px3.getText().length()!=0||py3.getText().length()!=0)|| trait!=null || epaisseurtriangle.getText().length()!=0){
						if((px1.getText().length()==0||py1.getText().length()==0 ||px2.getText().length()==0||py2.getText().length()==0||px3.getText().length()==0||py3.getText().length()==0)&&trait!=null&&epaisseurtriangle.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((px1.getText().length()==0||py1.getText().length()==0 ||px2.getText().length()==0||py2.getText().length()==0||px3.getText().length()==0||py3.getText().length()==0)&&trait==null&&epaisseurtriangle.getText().length()!=0){
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurtriangle.getText()));		
						}else if((px1.getText().length()==0||py1.getText().length()==0 ||px2.getText().length()==0||py2.getText().length()==0||px3.getText().length()==0||py3.getText().length()==0)&&trait!=null&&epaisseurtriangle.getText().length()!=0){
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseurtriangle.getText()));
						}else{	
							int p1x=Integer.parseInt(px1.getText());
							int p1y=Integer.parseInt(py1.getText());
							int p2x=Integer.parseInt(px2.getText());
							int p2y=Integer.parseInt(py2.getText());
							int p3x=Integer.parseInt(px3.getText());
							int p3y=Integer.parseInt(py3.getText());
								if(trait!=null&&epaisseurtriangle.getText().length()==0)
									dessin.liste.add(new Triangle(new Point(p1x,p1y),new Point(p2x,p2y),new Point(p3x,p3y),trait,dessin.liste.get(tmpform).epaisseur));
								else if(trait==null&&epaisseurtriangle.getText().length()!=0)
									dessin.liste.add(new Triangle(new Point(p1x,p1y),new Point(p2x,p2y),new Point(p3x,p3y),dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseurtriangle.getText())));
								else if(trait==null&&epaisseurtriangle.getText().length()==0)
									dessin.liste.add(new Triangle(new Point(p1x,p1y),new Point(p2x,p2y),new Point(p3x,p3y),dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));
								else
									dessin.liste.add(new Triangle(new Point(p1x,p1y),new Point(p2x,p2y),new Point(p3x,p3y),trait,(float)Integer.parseInt(epaisseurtriangle.getText())));
								
								dessin.liste.remove(dessin.liste.get(tmpform));
							}
					}	
					dessin.repaint();
					changeformtriangle.setVisible(false);
					trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformtriangle.setVisible(false);
		changeformtriangle.add(dispositionformulaire);
		body.add(changeformtriangle);




		//Forme ligne
		changeformligne=new JPanel();
		dispositionformulaire=new Box(BoxLayout.Y_AXIS);
		changeformligne.setBorder(lineborder);
		changeformligne.setMaximumSize(new Dimension(2700, Short.MAX_VALUE));

		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("posx point 1:");
		dispositionformulaire.add(text);
		JTextField px1l = new JTextField(10);
		px1l.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(px1l);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posy point 1:");
		dispositionformulaire.add(text);
		JTextField py1l = new JTextField(10);
		py1l.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(py1l);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posx point 2:");
		dispositionformulaire.add(text);
		JTextField px2l = new JTextField(10);
		px2l.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(px2l);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));

		text = new JLabel("posy point 2:");
		dispositionformulaire.add(text);
		JTextField py2l = new JTextField(10);
		py2l.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume();
        			}
     			}
		});
		dispositionformulaire.add(py2l);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)epaisseur:");
		dispositionformulaire.add(text);
		JTextField epaisseur = new JTextField(10);
		epaisseur.addKeyListener(new KeyAdapter() {
    			public void keyTyped(KeyEvent e) {
        		char c = e.getKeyChar();
        		if ( ((c < '0') || (c > '9'))) {
            		e.consume(); 
        			}
     			}
		});
		dispositionformulaire.add(epaisseur);	
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		text = new JLabel("(option)couleur:");
		dispositionformulaire.add(text);
		button=new Button("COULEUR");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
				JColorChooser colorchooser =new JColorChooser();
				trait =JColorChooser.showDialog(null,"coulleur de la forme",Color.black);
				}
			}
		);
 		dispositionformulaire.add(button);
		dispositionformulaire.add(Box.createRigidArea(new Dimension(0,10)));
		button = new Button("ENVOYER");
		button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e){
					if((px1l.getText().length()!=0||py1l.getText().length()!=0 ||px2l.getText().length()!=0||py2l.getText().length()!=0)|| trait!=null || epaisseur.getText().length()!=0){
						if((px1l.getText().length()==0||py1l.getText().length()==0 ||px2l.getText().length()==0||py2l.getText().length()==0)&&trait!=null&&epaisseur.getText().length()==0){
							dessin.liste.get(tmpform).setColor(trait);
						}else if((px1l.getText().length()==0||py1l.getText().length()==0 ||px2l.getText().length()==0||py2l.getText().length()==0)&&trait==null&&epaisseur.getText().length()!=0){
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseur.getText()));		
						}else if((px1l.getText().length()==0||py1l.getText().length()==0 ||px2l.getText().length()==0||py2l.getText().length()==0)&&trait!=null&&epaisseur.getText().length()!=0){
							dessin.liste.get(tmpform).setColor(trait);
							dessin.liste.get(tmpform).setEpaisseur((float)Integer.parseInt(epaisseur.getText()));
						}else{	
								int p1x=Integer.parseInt(px1l.getText());
								int p1y=Integer.parseInt(py1l.getText());
								int p2x=Integer.parseInt(px2l.getText());
								int p2y=Integer.parseInt(py2l.getText());
								if(trait!=null&&epaisseur.getText().length()==0)
									dessin.liste.add(new Ligne(new Point(p1x,p1y),new Point(p2x,p2y),trait,dessin.liste.get(tmpform).epaisseur));
								else if(trait==null&&epaisseur.getText().length()!=0)
									dessin.liste.add(new Ligne(new Point(p1x,p1y),new Point(p2x,p2y),dessin.liste.get(tmpform).ctrait,(float)Integer.parseInt(epaisseur.getText())));
								else if(trait==null&&epaisseur.getText().length()==0)
									dessin.liste.add(new Ligne(new Point(p1x,p1y),new Point(p2x,p2y),dessin.liste.get(tmpform).ctrait,dessin.liste.get(tmpform).epaisseur));
								else
									dessin.liste.add(new Ligne(new Point(p1x,p1y),new Point(p2x,p2y),trait,(float)Integer.parseInt(epaisseur.getText())));
								
								dessin.liste.remove(dessin.liste.get(tmpform));
							}
					}						
					dessin.repaint();
					changeformligne.setVisible(false);
					trait=null;
				}
			}
		);
 		dispositionformulaire.add(button);
		changeformligne.setVisible(false);
		changeformligne.add(dispositionformulaire);
		body.add(changeformligne);




		//FINFORMULAIRE
		dessin.setSize(Short.MAX_VALUE,Short.MAX_VALUE);
		dessin.addMouseListener(this);
		dessin.addMouseMotionListener(this);	
		body.add(dessin);
		fond.add(body);
 		this.add(fond);


		setLocationRelativeTo(null); 
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
	}
		public void  mouseMoved(MouseEvent e){}
		public void mouseClicked(MouseEvent e){}
                private void pressed(MouseEvent e){ 
			select=-1;
				if(e.getButton()==MouseEvent.BUTTON1){
					if(!butpoint&&!butligne&&!butrect&&!butcarre&&!butellipse&&!butcercle&&!buttriangle){	
						for(int i=0;i<dessin.liste.size();i++){
							int dx=e.getX()-dessin.liste.get(i).posx;
							int dy=e.getY()-dessin.liste.get(i).posy;
								if((Math.sqrt(dx*dx+dy*dy))<30){
									select=i;
									if(hitmodif==true){
									if(dessin.liste.get(select) instanceof Rectangle){
										changeformrect.setVisible(true);
					        				changeformcarre.setVisible(false);
										changeformcircle.setVisible(false);
										changeformtriangle.setVisible(false);
										changeformligne.setVisible(false);
										changeformellipse.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									if(dessin.liste.get(select) instanceof Ligne){
										changeformligne.setVisible(true);
										changeformrect.setVisible(false);
					        				changeformcarre.setVisible(false);
										changeformcircle.setVisible(false);
										changeformtriangle.setVisible(false);
										changeformellipse.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									if(dessin.liste.get(select) instanceof Ellipse){
										changeformellipse.setVisible(true);
										changeformrect.setVisible(false);
					        				changeformcarre.setVisible(false);
										changeformcircle.setVisible(false);
										changeformtriangle.setVisible(false);
										changeformligne.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									if(dessin.liste.get(select) instanceof Triangle){
										changeformtriangle.setVisible(true);
										changeformrect.setVisible(false);
					        				changeformcarre.setVisible(false);
										changeformcircle.setVisible(false);
										changeformligne.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									if(dessin.liste.get(select) instanceof Carre){
										changeformcarre.setVisible(true);
										changeformrect.setVisible(false);
										changeformcircle.setVisible(false);
										changeformtriangle.setVisible(false);
										changeformligne.setVisible(false);
										changeformellipse.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									if(dessin.liste.get(select) instanceof Cercle){
										changeformcircle.setVisible(true);
										changeformrect.setVisible(false);
					        				changeformcarre.setVisible(false);
										changeformtriangle.setVisible(false);
										changeformligne.setVisible(false);
										changeformellipse.setVisible(false);
										trait=null;
										tmpform=select;	
									}
									}
								}	
						}
					}else{
					if(butpoint){
					dessin.liste.add(new Point(e.getX(),e.getY()));
					butpoint=false;
					dessin.repaint();
					}
					if(butligne){
					dessin.liste.add(new Ligne(new Point(e.getX(),e.getY()),new Point(e.getX()+100,e.getY())));
					butligne=false;
					dessin.repaint();
					}
					if(butrect){
					dessin.liste.add(new Rectangle(e.getX(),e.getY(),20,40));
					butrect=false;
					dessin.repaint();
					}
					if(butcarre){
					dessin.liste.add(new Carre(e.getX(),e.getY(),60));
					butcarre=false;
					dessin.repaint();
					}
					if(butellipse){
					dessin.liste.add(new Ellipse(40,60,e.getX(),e.getY()));
					butellipse=false;
					dessin.repaint();
					}
					if(butcercle){
					dessin.liste.add(new Cercle(60,e.getX(),e.getY()));
					butcercle=false;
					dessin.repaint();
					}
					if(buttriangle){
					dessin.liste.add(new Triangle(new Point(e.getX(),e.getY()),new Point(e.getX()+20,e.getY()),new Point(e.getX()+10,e.getY()-15)));
					buttriangle=false;
					dessin.repaint();
					}
					}
				}
		}
        public void mouseEntered(MouseEvent e){}
        public void mouseExited(MouseEvent e){}
        private void released(MouseEvent e){
			if(delete==true){
				dessin.liste.remove(dessin.liste.get(select));
				dessin.repaint();
				}
		select=-1;
		}
		public void mousePressed(MouseEvent e){pressed(e);}
		public void mouseReleased(MouseEvent e){released(e);}
		public void mouseDragged(MouseEvent e){
			if(select!=-1 && ! delete){ 
				dessin.liste.get(select).move(e.getX(),e.getY());
				dessin.repaint();
			}
		}


		public static void main(String[] toto){
			Screen frame= new Screen();
		
		}	

}

