package mypackage;
import java.awt.Graphics;
import java.awt.Color;

public class Cercle extends Ellipse {

	
 public	Cercle(int rayon,int x, int y){
	super(rayon,rayon,x,y);
	}

 public	Cercle(int rayon,int x, int y,Color nvx){
	super(rayon,rayon,x,y,nvx);
	}

 public	Cercle(int rayon,int x, int y,float epais){
	super(rayon,rayon,x,y,epais);
	}

 public	Cercle(int rayon,int x, int y,Color nvx, float epais){
	super(rayon,rayon,x,y,nvx,epais);
	}

 public	void move(int x, int y){
	super.move(x,y);
	}	

	void paint(Graphics g){
	super.paint(g);
	}
}