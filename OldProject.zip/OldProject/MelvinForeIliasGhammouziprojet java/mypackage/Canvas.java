package mypackage;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.util.ArrayList;

public class Canvas extends JPanel{
 public static ArrayList<Formegeo> liste;
 public	 Canvas(){
	liste=new ArrayList<Formegeo>();
	this.setBackground(Color.white);
	}

 	public void paintComponent(Graphics g){
	super.paintComponent(g);
	for(int i=0; i<liste.size();i++)
	liste.get(i).paint(g);
	}
}