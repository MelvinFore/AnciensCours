package mypackage;
import java.awt.Graphics;
import java.awt.Color;

public class Point extends Formegeo{
int radius=4;

 public Point(){
	super(0,0);
	radius=0;
	}

 public	Point( int x, int y ) {
		super(x,y);
	}

 public	Point( int x, int y, Color ajout) {
		super(x,y,ajout);
	}

  public void move(int x, int y){
		this.posx=x;
		this.posy=y;
	}

 void paint(Graphics g){
 g.setColor(ctrait);
 g.fillOval(posx,posy,radius,radius);
}
	
}
