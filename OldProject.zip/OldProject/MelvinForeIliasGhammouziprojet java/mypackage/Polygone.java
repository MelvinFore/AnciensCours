package mypackage;
import java.awt.Graphics;
import java.awt.Color;

public class Polygone extends Polyligne{
	
	public Polygone(){
		super();
	}
	
		
	public void paint(Graphics g){
		super.paint(g);
		g.drawLine(Pts.get(0).posx,Pts.get(0).posy,Pts.get(Pts.size()-1).posx,Pts.get(Pts.size()-1).posy);
	}
}	