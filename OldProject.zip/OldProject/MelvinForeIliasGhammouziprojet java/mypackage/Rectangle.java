package mypackage;
import java.awt.Graphics;
import java.awt.Color;

public class Rectangle extends Polygone{
public int dlongueur;
public int dlargeur;
	
 public	Rectangle(int x ,int y ,int longueur ,int largeur){
	super();	
	this.posx=x+(int)(largeur/2);
	this.posy=y+(int)(longueur/2);
	Point d1=new Point(x,y);
	Point d2=new Point(x+largeur,y);	
	Point d3=new Point(x,y+longueur);
	Point d4=new Point(x+largeur,y+longueur);
	Pts.add(d1);
	Pts.add(d2);
	Pts.add(d4);
	Pts.add(d3);
	dlongueur=(int)(longueur/2);
	dlargeur=(int)(largeur/2);
	}

public	Rectangle(int x ,int y ,int longueur ,int largeur, Color nvx){
	super();	
	this.posx=x+(int)(largeur/2);
	this.posy=y+(int)(longueur/2);
	Point d1=new Point(x,y);
	Point d2=new Point(x+largeur,y);	
	Point d3=new Point(x,y+longueur);
	Point d4=new Point(x+largeur,y+longueur);
	Pts.add(d1);
	Pts.add(d2);
	Pts.add(d4);
	Pts.add(d3);
	dlongueur=(int)(longueur/2);
	dlargeur=(int)(largeur/2);
	ctrait=nvx;
	}

public	Rectangle(int x ,int y ,int longueur ,int largeur,float epais){
	super();	
	this.posx=x+(int)(largeur/2);
	this.posy=y+(int)(longueur/2);
	Point d1=new Point(x,y);
	Point d2=new Point(x+largeur,y);	
	Point d3=new Point(x,y+longueur);
	Point d4=new Point(x+largeur,y+longueur);
	Pts.add(d1);
	Pts.add(d2);
	Pts.add(d4);
	Pts.add(d3);
	dlongueur=(int)(longueur/2);
	dlargeur=(int)(largeur/2);
	epaisseur=epais;
	}

public	Rectangle(int x ,int y ,int longueur ,int largeur,Color nvx,float epais){
	super();	
	this.posx=x+(int)(largeur/2);
	this.posy=y+(int)(longueur/2);
	Point d1=new Point(x,y);
	Point d2=new Point(x+largeur,y);	
	Point d3=new Point(x,y+longueur);
	Point d4=new Point(x+largeur,y+longueur);
	Pts.add(d1);
	Pts.add(d2);
	Pts.add(d4);
	Pts.add(d3);
	dlongueur=(int)(longueur/2);
	dlargeur=(int)(largeur/2);
	ctrait=nvx;
	epaisseur=epais;
	}

	public void move(int x,int y){
		this.posx=x;
		this.posy=y;
		this.Pts.get(0).posx=x-this.dlargeur;
		this.Pts.get(0).posy=y-this.dlongueur;
		this.Pts.get(1).posx=x+this.dlargeur;
		this.Pts.get(1).posy=y-this.dlongueur;
		this.Pts.get(2).posx=x+this.dlargeur;
		this.Pts.get(2).posy=y+this.dlongueur;
		this.Pts.get(3).posx=x-this.dlargeur;
		this.Pts.get(3).posy=y+this.dlongueur;
	}

	public void paint(Graphics g){
		super.paint(g);
	}	
	
}