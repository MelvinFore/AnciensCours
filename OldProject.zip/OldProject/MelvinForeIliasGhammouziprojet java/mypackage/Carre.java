package mypackage;
import java.awt.Graphics;
import java.awt.Color;

public class Carre extends Rectangle{
	
 public	Carre(int x, int y, int longueur){
		super(x,y,longueur,longueur);	
	}

 public	Carre(int x, int y, int longueur,Color nvx){
		super(x,y,longueur,longueur,nvx);	
	}

 public	Carre(int x, int y, int longueur,float epais){
		super(x,y,longueur,longueur,epais);	
	}

 public	Carre(int x, int y, int longueur,Color nvx, float epais){
		super(x,y,longueur,longueur,nvx,epais);	
	}
	
	public void move(int x,int y){
		super.move(x,y);			
	}	
	

	
	public void paint(Graphics g){
		super.paint(g);
	}	
} 