package mypackage;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.util.ArrayList;
import java.awt.BasicStroke;

public class Polyligne extends Formegeo{
	protected ArrayList<Point> Pts;
	
	public Polyligne(){
		super();
		Pts = new ArrayList<Point>();
	}
	
		
	void paint(Graphics g1){
		Graphics2D g=(Graphics2D)g1;
		BasicStroke line = new BasicStroke(epaisseur);
		g.setStroke(line);
		g.setColor(ctrait);
		for(int i=1; i<Pts.size(); i++){
			g.drawLine(Pts.get(i-1).posx,Pts.get(i-1).posy,Pts.get(i).posx,Pts.get(i).posy);
		}
	}
}	