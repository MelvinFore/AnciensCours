package mypackage;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Save {

 public void stockage(ArrayList<Formegeo> recup, String filename) {

     try {
	String finalname;	
       if(filename.length()==0)
	finalname="nameless";
	else
	finalname=filename;
       FileOutputStream fileOut = new FileOutputStream(finalname+".ser");
       ObjectOutputStream out = new ObjectOutputStream(fileOut);
       for(int i=0;i<recup.size();i++){
       out.writeObject(recup.get(i));
       }
       out.close();
       fileOut.close();
       System.out.println("\nSerialisation terminee avec succes...\n");
 
     } catch (FileNotFoundException e) {
       e.printStackTrace();
     } catch (IOException e) {
       e.printStackTrace();
     }
  }
}