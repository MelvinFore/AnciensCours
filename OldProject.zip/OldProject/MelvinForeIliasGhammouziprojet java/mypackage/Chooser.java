package mypackage;
import javax.swing.*;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;
import java.lang.Math;
import java.io.File;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.*;

public class Chooser extends JFrame {

 public String path;

  public Chooser() {
 	  JFileChooser choose = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
 	  choose.setAcceptAllFileFilterUsed(false);
  	  FileNameExtensionFilter filter = new FileNameExtensionFilter("Fichier binaire", "ser");
  	  choose.addChoosableFileFilter(filter);
   	  int res = choose.showOpenDialog(null);
   		 if (res == JFileChooser.APPROVE_OPTION) {
      			path=choose.getSelectedFile().getPath();
    		}
 }
	public static void main(String[] toto){
	Chooser test=new Chooser();
	System.out.println(test.path);
}
}