package mypackage;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BasicStroke;

public class Ligne extends Polyligne{
int distx0;
int disty0;
int distx1;
int disty1;
	
 public	Ligne(Point p1, Point p2){
		Pts.add(p1);
		Pts.add(p2);
		posx=(int)((Pts.get(0).posx+Pts.get(1).posx)/2);
		posy=(int)((Pts.get(0).posy+Pts.get(1).posy)/2);
		distx0=Pts.get(0).posx-this.posx;
		disty0=Pts.get(0).posy-this.posy;
		distx1=Pts.get(1).posx-this.posx;
		disty1=Pts.get(1).posy-this.posy;
	}

 public	Ligne(Point p1, Point p2,Color nvx){
		Pts.add(p1);
		Pts.add(p2);
		posx=(int)((Pts.get(0).posx+Pts.get(1).posx)/2);
		posy=(int)((Pts.get(0).posy+Pts.get(1).posy)/2);
		distx0=Pts.get(0).posx-this.posx;
		disty0=Pts.get(0).posy-this.posy;
		distx1=Pts.get(1).posx-this.posx;
		disty1=Pts.get(1).posy-this.posy;
		ctrait=nvx;
	}

 public	Ligne(Point p1, Point p2,float epais){
		Pts.add(p1);
		Pts.add(p2);
		posx=(int)((Pts.get(0).posx+Pts.get(1).posx)/2);
		posy=(int)((Pts.get(0).posy+Pts.get(1).posy)/2);
		distx0=Pts.get(0).posx-this.posx;
		disty0=Pts.get(0).posy-this.posy;
		distx1=Pts.get(1).posx-this.posx;
		disty1=Pts.get(1).posy-this.posy;
		epaisseur=epais;
	}

 public	Ligne(Point p1, Point p2,Color nvx,float epais){
		Pts.add(p1);
		Pts.add(p2);
		posx=(int)((Pts.get(0).posx+Pts.get(1).posx)/2);
		posy=(int)((Pts.get(0).posy+Pts.get(1).posy)/2);
		distx0=Pts.get(0).posx-this.posx;
		disty0=Pts.get(0).posy-this.posy;
		distx1=Pts.get(1).posx-this.posx;
		disty1=Pts.get(1).posy-this.posy;
		ctrait=nvx;
		epaisseur=epais;
	}
	
	public void move(int x,int y){
	this.posx=x;
	this.posy=y;
	Pts.get(0).move(x+distx0,y+disty0);
	Pts.get(1).move(x+distx1,y+disty1);
	}
	void paint(Graphics g1){
		Graphics2D g=(Graphics2D)g1;
		BasicStroke line = new BasicStroke(epaisseur);
		g.setStroke(line);
		g.setColor(ctrait);
		g.drawLine(Pts.get(0).posx,Pts.get(0).posy,Pts.get(1).posx,Pts.get(1).posy);
	}
}