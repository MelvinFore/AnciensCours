package mypackage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class Load{

 public ArrayList<Formegeo> destockage(String name){
	 ArrayList<Formegeo> recup= new ArrayList<Formegeo>();
    try {
      FileInputStream fileIn = new FileInputStream(name);
      ObjectInputStream ois = new ObjectInputStream(fileIn);
      while(ois!=null){
      recup.add((Formegeo) ois.readObject());
      }
      ois.close();
      fileIn.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
       e.printStackTrace();
    }
return recup;
}
}