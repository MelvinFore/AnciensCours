package mypackage;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.BasicStroke;

public class Ellipse extends Formegeo {
int premaxe;
int secondaxe;

	
 public	Ellipse(int demiaxeA, int demiaxeB,int x, int y){
	super(x,y);
	premaxe=demiaxeA;
	secondaxe=demiaxeB;
	}

 public	Ellipse(int demiaxeA, int demiaxeB,int x, int y,Color nvx){
	super(x,y);
	premaxe=demiaxeA;
	secondaxe=demiaxeB;
	ctrait=nvx;
	}

 public	Ellipse(int demiaxeA, int demiaxeB,int x, int y,float epais){
	super(x,y);
	premaxe=demiaxeA;
	secondaxe=demiaxeB;
	epaisseur=epais;
	}

 public	Ellipse(int demiaxeA, int demiaxeB,int x, int y,Color nvx,float epais){
	super(x,y);
	premaxe=demiaxeA;
	secondaxe=demiaxeB;
	ctrait=nvx;
	epaisseur=epais;
	}

 public	void move(int x,int y){
	this.posx=x;
	this.posy=y;
	}

void paint(Graphics g1){
	Graphics2D g=(Graphics2D)g1;
	BasicStroke line = new BasicStroke(epaisseur);
	g.setStroke(line);
	g.setColor(ctrait);
	g.drawOval(posx,posy,premaxe,secondaxe);
}
}