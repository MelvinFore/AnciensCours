package mypackage;
import java.io.Serializable;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.BasicStroke;

 public abstract class Formegeo implements Serializable{
 	public int posx, posy;
	public Color ctrait=Color.black;
	public float epaisseur=1.0f;

 public	Formegeo(){
		posx=0;
		posy=0;
	}

 public	Formegeo(int x, int y){
		posx=x;
		posy=y;
	}

 public	Formegeo(int x, int y, Color nvx){
		posx=x;
		posy=y;
		ctrait=nvx;
	}

 public void setColor(Color nvx){
	ctrait=nvx;
	}

 public void setEpaisseur(float nvx){
	epaisseur=nvx;
	}

 public	void move(int x, int y){
	
	}


 abstract  void paint(Graphics g);

}
