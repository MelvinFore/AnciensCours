package mypackage;
import java.awt.Graphics;
import java.awt.Color;
public class Triangle extends Polygone{

int distx0;
int distx1;
int distx2;
int disty0;
int disty1;
int disty2;

 public	Triangle(Point prem, Point seconde, Point dernier){
		super();
		Pts.add(prem);
		Pts.add(seconde);
		Pts.add(dernier);
		this.posx=(int)((prem.posx+seconde.posx+dernier.posx)/3);
		this.posy=(int)((prem.posy+seconde.posy+dernier.posy)/3);
		distx0=prem.posx-this.posx;
		disty0=prem.posy-this.posy;
		distx1=seconde.posx-this.posx;
		disty1=seconde.posy-this.posy;
		distx2=dernier.posx-this.posx;
		disty2=dernier.posy-this.posy;
	
	}

 public	Triangle(Point prem, Point seconde, Point dernier,Color nvx){
		super();
		Pts.add(prem);
		Pts.add(seconde);
		Pts.add(dernier);
		this.posx=(int)((prem.posx+seconde.posx+dernier.posx)/3);
		this.posy=(int)((prem.posy+seconde.posy+dernier.posy)/3);
		distx0=prem.posx-this.posx;
		disty0=prem.posy-this.posy;
		distx1=seconde.posx-this.posx;
		disty1=seconde.posy-this.posy;
		distx2=dernier.posx-this.posx;
		disty2=dernier.posy-this.posy;
		ctrait=nvx;
	
	}

 public	Triangle(Point prem, Point seconde, Point dernier, float epais){
		super();
		Pts.add(prem);
		Pts.add(seconde);
		Pts.add(dernier);
		this.posx=(int)((prem.posx+seconde.posx+dernier.posx)/3);
		this.posy=(int)((prem.posy+seconde.posy+dernier.posy)/3);
		distx0=prem.posx-this.posx;
		disty0=prem.posy-this.posy;
		distx1=seconde.posx-this.posx;
		disty1=seconde.posy-this.posy;
		distx2=dernier.posx-this.posx;
		disty2=dernier.posy-this.posy;
		epaisseur=epais;
	
	}

 public	Triangle(Point prem, Point seconde, Point dernier,Color nvx, float epais){
		super();
		Pts.add(prem);
		Pts.add(seconde);
		Pts.add(dernier);
		this.posx=(int)((prem.posx+seconde.posx+dernier.posx)/3);
		this.posy=(int)((prem.posy+seconde.posy+dernier.posy)/3);
		distx0=prem.posx-this.posx;
		disty0=prem.posy-this.posy;
		distx1=seconde.posx-this.posx;
		disty1=seconde.posy-this.posy;
		distx2=dernier.posx-this.posx;
		disty2=dernier.posy-this.posy;
		epaisseur=epais;
		ctrait=nvx;
	
	}

	public void move(int x,int y){
	this.posx=x;
	this.posy=y;
	Pts.get(0).move(x+distx0,y+disty0);
	Pts.get(1).move(x+distx1,y+disty1);
	Pts.get(2).move(x+distx2,y+disty2);
	}

	public void paint(Graphics g){
	super.paint(g);
	}
	

}
