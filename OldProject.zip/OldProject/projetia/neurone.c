#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

typedef struct elemg{
  float tabpoidsW[100];
  float Y;
  float E;
  float H;
}node, *elemg;

float sigmoid(float x){
  x=(1.0/(1.0+expf(-1*5*x)));
  return x;
}

float derivsigmoid(float x){
  x=sigmoid(x)*(1-sigmoid(x));
  return x;
}

node *creapremnode(){
  node *n=malloc(sizeof(node));
  for(int i=0;i<100;i++){
    n->tabpoidsW[100]=-100000;
    n->H=0;
  }
}

void count(int* c, int* l){
  FILE * inputFile;
  char buffer[200];
  char d[]=",";
  char* tok;
  int prem=1;
  inputFile = fopen( "train1.csv", "r" );
  if ( inputFile == NULL ) {
      exit( 0 );
  }
  fgets(buffer,200,inputFile);
  while(! feof( inputFile)){
    fgets(buffer,200,inputFile);
    if(buffer[strlen(buffer)-1]=='\n'){
      tok=strtok(buffer,d);
      while(tok!=NULL){
        if(prem==1){
          *c=*c+1;
        }
        tok=strtok(NULL,d);
      }
      if(prem==1)
        prem=0;
      *l=*l+1;
    }
  }

  fclose( inputFile );
}

void lirefich(float valmax[] ,int nbc,int nbl,float dc[nbl][nbc] ) {

    FILE * inputFile;
    char buffer[200];
    char* tok;
    char d[]=",";
    int prem=1;
    int countc=nbc,countl=nbl;
    int c=0, l=0;
    for(int x=0;x<countc;x++){
      valmax[x]=0;
    }
    inputFile = fopen( "train1.csv", "r" );
    if ( inputFile == NULL ) {
        printf( "Cannot open file \n" );
        exit( 0 );
    }
    fgets(buffer,200,inputFile);
    while(! feof( inputFile)){
      fgets(buffer,200,inputFile);
      if(buffer[strlen(buffer)-1]=='\n'){
        tok=strtok(buffer,d);
        while(tok!=NULL){
          dc[l][c]=atof(tok);
          if(valmax[c]<atof(tok)){
            valmax[c]=atof(tok);
          }
          c++;
          tok=strtok(NULL,d);
        }
        c=0;
        l++;
      }
    }
    fclose( inputFile );
}


int main(){
  srand( time( NULL ) );
  int nbc=0,nbl=0,boolerr=0,nbfalse=100000000,limitvaltrain,debvalconstat,nbfalselimit;
  count(&nbc,&nbl);
  float docdonnee[nbl][nbc];
  float tabvalmax[nbc];
  float somme=0.0;
  float margerr;
  lirefich(tabvalmax,nbc,nbl,docdonnee);
  node* layer0[nbc-1];
  node* layer1[nbc-2];
  node* final;

  for(int i=0; i<nbc-1;i++){
    layer0[i]=NULL;
  }

  for(int i=0; i<nbc-2;i++){
    layer0[i]=NULL;
  }
  //On tranforme les valeur en pourcentage
    for(int i=0;i<nbc;i++){
      for(int x=0;x<nbl;x++){
        docdonnee[x][i]=(docdonnee[x][i]/tabvalmax[i]);
      }
    }
  //Initialisation des noeud
  for(int i=0;i<nbc-1;i++){
    layer0[i]=creapremnode();
    //init poids de la couche 0
    for(int x=0;x<nbc-1;x++){
      layer0[i]->tabpoidsW[x]=-0.01 + (float)rand() / ((float)RAND_MAX/(0.01-(-0.01)));
    }
  }

  for(int i=0;i<nbc-2;i++){
    layer1[i]=creapremnode();
  //init poids de la couche 1
    for(int x=0;x<nbc-1;x++){
      layer1[i]->tabpoidsW[x]=-0.01 + (float)rand() / ((float)RAND_MAX/(0.01-(-0.01)));
    }
  }

  final=creapremnode();
  //init poids de la derniere couche
  for(int x=0;x<nbc-2;x++){
    final->tabpoidsW[x]=-0.01 + (float)rand() / ((float)RAND_MAX/(0.01-(-0.01)));
  }

limitvaltrain=(((nbl-1)*80)/100);//derniere valeur dont on se servira pour s'entrainer
nbfalselimit=(limitvaltrain*10)/100;
debvalconstat=limitvaltrain+1;//premiere valeur qui permettra de tester notre ia

  //DEBUT DE L'AJUSTEMENT DES POIDS
   while(boolerr==0 && nbfalse>nbfalselimit){
      boolerr=1;
      nbfalse=0;
      for(int stoc=0;stoc<limitvaltrain;stoc++){
      //calcul du y couche 0
    for(int indice=0;indice<nbc-1;indice++){
      for(int i=0;i<nbc-1;i++){
        layer0[indice]->H=layer0[indice]->H+(layer0[indice]->tabpoidsW[i]*docdonnee[stoc][i]);
      }
      layer0[indice]->Y=sigmoid(layer0[indice]->H);
    }

    //calcul du y couche 1
    for(int indice=0;indice<nbc-2;indice++){
      for(int i=0;i<nbc-1;i++){
        layer1[indice]->H=layer1[indice]->H+(layer1[indice]->tabpoidsW[i]*layer0[i]->Y);
      }
      layer1[indice]->Y=sigmoid(layer1[indice]->H);
    }

    //calcul du y couche final
    for(int i=0;i<nbc-2;i++){
      final->H=final->H+(final->tabpoidsW[i]*layer1[i]->Y);
    }
    final->Y=sigmoid(final->H);
        margerr=(docdonnee[stoc][nbc-1]*10)/100;

    //On verifie si la sortie obtenue correspond a la sortie attendu
    if(!((final->Y<=docdonnee[stoc][nbc-1]+margerr)&&(final->Y>=docdonnee[stoc][nbc-1]-margerr))){
            boolerr=0;
            nbfalse++;
      //calcul erreur couche final
      final->E=(docdonnee[stoc][nbc-1]-final->Y);
      //retropropagation de l'erreur
      //couche 1
      for(int indice=0;indice<nbc-2;indice++){
        layer1[indice]->E=derivsigmoid(layer1[indice]->H)*final->E*final->tabpoidsW[indice];
      }
      //retropropagation de l'erreur
      //couche 0
      for(int indice=0;indice<nbc-1;indice++){
        somme=0;
          for(int x=0;x<nbc-2;x++){
            somme=somme+(layer1[x]->E*layer1[x]->tabpoidsW[indice]);
          }
          layer0[indice]->E=derivsigmoid(layer0[indice]->H)*somme;
      }

      //calcul des nouveaux poids
      //couche 0
      for(int indice=0; indice<nbc-1;indice++){
        for(int x=0;x<nbc-1;x++){
          layer0[indice]->tabpoidsW[x]=layer0[indice]->tabpoidsW[x]+(0.1*layer0[indice]->E*docdonnee[stoc][x]);
        }
      }
      //calcul des nouveaux poids
      //couche 1
      for(int indice=0; indice<nbc-2;indice++){
        for(int x=0;x<nbc-1;x++){
          layer1[indice]->tabpoidsW[x]=layer1[indice]->tabpoidsW[x]+(0.1*layer1[indice]->E*layer0[x]->Y);
        }
      }
      //calcul des nouveaux poids
      //couche final
      for(int x=0;x<nbc-2;x++){
        final->tabpoidsW[x]=final->tabpoidsW[x]+(0.1*final->E*layer1[x]->Y*derivsigmoid(final->H));
      }
  }

      //REMISE DES H A ZERO
    for(int indice=0;indice<nbc-1;indice++){
      layer0[indice]->H=0;
    }

    for(int indice=0;indice<nbc-2;indice++){
      layer1[indice]->H=0;
    }
    final->H=0;
  }
  printf("%d\n",nbfalse);
}//FIN WHILE
nbfalse=0;


//ON verifie que notre reseau de neuronne a marché
for(int stoc=debvalconstat;stoc<nbl-1;stoc++){
  //calcul du y couche 0
  for(int indice=0;indice<nbc-1;indice++){
      for(int i=0;i<nbc-1;i++){
        layer0[indice]->H=layer0[indice]->H+(layer0[indice]->tabpoidsW[i]*docdonnee[stoc][i]);
      }
      layer0[indice]->Y=sigmoid(layer0[indice]->H);
  }

  //calcul du y couche 1
  for(int indice=0;indice<nbc-2;indice++){
    for(int i=0;i<nbc-1;i++){
      layer1[indice]->H=layer1[indice]->H+(layer1[indice]->tabpoidsW[i]*layer0[i]->Y);
    }
    layer1[indice]->Y=sigmoid(layer1[indice]->H);
  }

  //calcul du y couche final
  for(int i=0;i<nbc-2;i++){
    final->H=final->H+(final->tabpoidsW[i]*layer1[i]->Y);
  }
  final->Y=sigmoid(final->H);

  if(!((final->Y<=docdonnee[stoc][nbc-1]+margerr)&&(final->Y>=docdonnee[stoc][nbc-1]-margerr))){
          nbfalse++;
  }

  //REMISE DES H A ZERO
for(int indice=0;indice<nbc-1;indice++){
  layer0[indice]->H=0;
}

for(int indice=0;indice<nbc-2;indice++){
  layer1[indice]->H=0;
}
final->H=0;
}

  printf("\n On a %d pourcent d'erreur au final dans nos prédictions",((100*nbfalse)/((nbl-1)-debvalconstat)) );

}
