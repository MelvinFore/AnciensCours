#ifndef DEF_MENU
#define DEF_MENU

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "math.h"

class Menu{
public:
  sf::Sprite startsprt;
  sf::Sprite exitsprt;
  sf::Texture startxt;
  sf::Texture exitxt;
  sf::RectangleShape popup;

  Menu(int w,int h);

};
#endif
