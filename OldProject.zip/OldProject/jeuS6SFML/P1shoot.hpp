#ifndef DEF_P1SHOOT
#define DEF_P1SHOOT
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <string>
#include <vector>
#include "math.h"


class P1shoot{
public:
    sf::Sprite bltsprite;
    sf::Texture bltext;
    P1shoot(sf::Vector2f pos);
    void setpos(sf::Vector2f pos);
};

#endif
