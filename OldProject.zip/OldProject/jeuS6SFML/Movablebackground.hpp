#ifndef DEF_MOVABLEBACKGROUND
#define DEF_MOVABLEBACKGROUND

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>

class MovableBackground
{
public:
        MovableBackground();
        void Update(sf::RenderWindow &window, float vitesse);
        void Render(sf::RenderWindow &window);

private:
        sf::Texture bgTex;
        sf::RectangleShape bgShape;
        sf::RectangleShape bgShape2;
        sf::Vector2f bgSize;
        float bgSpeed;
        float bgY;
        float bgY2;
};
#endif
