#include "Menu.hpp"

Menu :: Menu(int w,int h){
  if (!startxt.loadFromFile("./image/start.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  if (!exitxt.loadFromFile("./image/exit.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  startsprt.setTexture(startxt);
  exitsprt.setTexture(exitxt);
  startsprt.setOrigin(61,16);
  exitsprt.setOrigin(61,16);
  startsprt.setPosition(w/2,h/2-100);
  exitsprt.setPosition(w/2,h/2+100);
  popup.setSize(sf::Vector2f(500, 600));
  popup.setFillColor(sf::Color::Black);
  popup.setOrigin(250,300);
  popup.setPosition(w/2,h/2);
}
