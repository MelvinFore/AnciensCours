#include "Movablebackground.hpp"


MovableBackground::MovableBackground()
{
        bgSpeed = 0.3;

        if (!bgTex.loadFromFile("./image/starscape.jpg"));
          {
            std::cerr << "impossible de charger la Texture" << std::endl;
          }
        bgTex.setSmooth(false);
        bgTex.setRepeated(true);

        bgY = bgShape.getPosition().y;
        bgSize.x = sf::VideoMode::getDesktopMode().width;
        bgSize.y = sf::VideoMode::getDesktopMode().height;
        bgShape.setTexture(&bgTex);
        bgShape.setSize(bgSize);
        bgShape2.setTexture(&bgTex);
        bgShape2.setSize(bgSize);
        bgShape2.setPosition(0,-bgSize.y+20 );
        bgY2 = bgShape2.getPosition().y;
}


void MovableBackground::Update(sf::RenderWindow &window, float vitesse)
{
        if (bgY < bgSize.y-30)
        {
                bgY += bgSpeed * vitesse;
        }else
                {
                        bgShape.setPosition(0,-bgSize.y+20 );
                        bgY = bgShape.getPosition().y;
                }
        bgShape.setPosition(0, bgY);

        if (bgY2 < bgSize.y-30)
        {
                bgY2 += bgSpeed * vitesse;
        }else
                {
                        bgShape2.setPosition(0,-bgSize.y+20 );
                        bgY2 = bgShape2.getPosition().y;
                }
        bgShape2.setPosition(0, bgY2);
}
void MovableBackground::Render(sf::RenderWindow &window)
{
        window.draw(bgShape);
        window.draw(bgShape2);
}
