#ifndef DEF_VAISSEAU
#define DEF_VAISSEAU

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include<vector>
#include <unistd.h>
#include "P1shoot.hpp"
#include "P2shoot.hpp"
#include "math.h"


class Vaisseau
{
  public:
    Vaisseau();
    void degat();
    void outbound(int w, int h);
    int vie;
    int cooldown=0;
    int invincibilite=-1;
    sf::Sprite vieGui[3];
    sf::Sprite vsprite;
    sf::Texture jtexture;
    sf::Texture box;
    sf::Texture heartbox;
    std::vector<P1shoot> P1lasers;
    std::vector<P2shoot> P2lasers;

};


#endif
