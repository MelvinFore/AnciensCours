#ifndef DEF_ASTEROID
#define DEF_ASTEROID

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "math.h"


class Asteroid{
public:
  Asteroid(sf::Vector2u window);
  int spawn(sf::RenderWindow &window);
  sf::Sprite astsprite;
  sf::Texture astexture;
  int spawndelai;
};
#endif
