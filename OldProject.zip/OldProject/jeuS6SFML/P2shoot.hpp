#ifndef DEF_P2shoot
#define DEF_P2shoot

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <string>
#include <vector>
#include "math.h"

class P2shoot{
public:
      sf::Vector2f currVelocity;
      float maxspeed;
      sf::Sprite bltsprite;
      sf::Texture bltext;
      sf::Vector2f playerCenter;
      sf::Vector2f aimDir;
      sf::Vector2f aimDirNorm;
      sf::Vector2f mousePosWindow;

      P2shoot()
        : currVelocity(0.f,0.f),maxspeed(15.f)
      {
        if (!this->bltext.loadFromFile("./image/tire.png"))
          {
            std::cerr << "impossible de charger la Texture" << std::endl;
          }
          this->bltsprite.setTexture(bltext);
      }
};

#endif
