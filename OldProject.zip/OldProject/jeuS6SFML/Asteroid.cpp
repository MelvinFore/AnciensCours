#include "Asteroid.hpp"

Asteroid :: Asteroid(sf::Vector2u window){
  spawndelai=0;
  if (!astexture.loadFromFile("./image/aste1.png"))
  {
    std::cerr << "impossible de charger la Texture astroid" << std::endl;
  }
  astsprite.setTexture(astexture);
  astsprite.setPosition(rand()%window.x-astsprite.getGlobalBounds().height,0);
}
int Asteroid::spawn(sf::RenderWindow &window){
  if(this->spawndelai<30){
    this->spawndelai++;
    return 0;
  }

  if(this->spawndelai>=30){
    this->astsprite.setPosition(rand()%window.getSize().x-this->astsprite.getGlobalBounds().height,0);
    this->spawndelai=0;
    return 1;
  }
      return 0;
}
