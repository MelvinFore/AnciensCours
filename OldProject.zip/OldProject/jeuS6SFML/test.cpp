#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <string>
#include <vector>
#include <string>
#include "math.h"
#include "time.h"
//mes bibliotheque
#include "Vaisseau.hpp"
#include "Asteroid.hpp"
#include "Menu.hpp"
#include "P1shoot.hpp"
#include "P2shoot.hpp"
#include "Movablebackground.hpp"



void InputHandler(sf::Event event, sf::RenderWindow &window, Vaisseau &s , P1shoot b, P2shoot b2,int* pause);
int game(sf::RenderWindow &window);

int main(){
  sf::Texture texture;
  sf::Texture hebergertxt;
  sf::Texture rejoindretxt;
  sf::Sprite hebergersprt;
  sf::Sprite rejoindresprt;
  sf::Vector2i mouse_pos;
  sf::RenderWindow window;
  sf::Text text;
  int hscreen=sf::VideoMode::getDesktopMode().height;
  int wscreen=sf::VideoMode::getDesktopMode().width;
  sf::Event event;
  sf::Font font;
  int c=2;
  if (!font.loadFromFile("./ressources/arial.ttf"))
  {
      std::cerr << "impossible de charger la police" << std::endl;
  }
  if (!hebergertxt.loadFromFile("./image/heberger.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  if (!rejoindretxt.loadFromFile("./image/rejoindre.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  hebergersprt.setTexture(hebergertxt);
  rejoindresprt.setTexture(rejoindretxt);
  text.setFont(font);
  text.setCharacterSize(70);
  text.setPosition(wscreen*2/5+90,hscreen/4);
  hebergersprt.setPosition(wscreen*2/5+30,hscreen*2/4);
  rejoindresprt.setPosition(wscreen*2/5+30,hscreen*3/4);
  text.setString("Odyssey");

  window.create(sf::VideoMode(sf::VideoMode::getDesktopMode().width,sf::VideoMode::getDesktopMode().height),"Space odyssey");
  sf::RectangleShape fond(sf::Vector2f(sf::VideoMode::getDesktopMode().width, sf::VideoMode::getDesktopMode().height));
  if (!texture.loadFromFile("./image/starscape.jpg"))
  {
    std::cerr << "impossible de charger le fond " << std::endl;
  }
  fond.setTexture(&texture);
  while(c==2){
    while (window.pollEvent(event))
    {
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space)){
            c=game(window);
        }
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
          mouse_pos = sf::Mouse::getPosition(window);
        }
        if(event.type==sf::Event::Closed){
            window.close();
            return 1;
          }
    }

    if(rejoindresprt.getGlobalBounds().contains(sf::Vector2f(mouse_pos))){
      mouse_pos=sf::Vector2i(0,0);

    }

    if(hebergersprt.getGlobalBounds().contains(sf::Vector2f(mouse_pos))){
      mouse_pos=sf::Vector2i(0,0);

    }
    window.clear();
    window.draw(fond);
    window.draw(text);
    window.draw(rejoindresprt);
    window.draw(hebergersprt);
    window.display();
  }
}


int game(sf::RenderWindow &window){
//INITIALISATION ECRAN
window.setFramerateLimit(30);
window.setVerticalSyncEnabled(true);
int hscreen=sf::VideoMode::getDesktopMode().height;
int wscreen=sf::VideoMode::getDesktopMode().width;

//INITIALISATION POPUP
Menu menu(wscreen,hscreen);
//INITIALISATION MUSIQUE
sf::Music music;
if(!music.openFromFile("./ressources/SPACE-TRAVELLER-Bikblades.ogg")){
  std::cerr << "impossible de charger la musique" << std::endl;
}
music.play();
music.setLoop(true);

//VARIABLES
//vaisseau
Vaisseau Nav;
P1shoot lp1(Nav.vsprite.getPosition());
P2shoot lp2;
sf::Vector2i mouse_pos;
//game
sf::Event event;
MovableBackground bg;
int score=0;
int pause=0;

//aff score
sf::Font font;
if (!font.loadFromFile("./ressources/arial.ttf"))
{
    std::cerr << "impossible de charger la police" << std::endl;
}
sf::Text text;
text.setFont(font);
text.setCharacterSize(24);
text.setPosition((wscreen*7)/8,0);

//save
std::ifstream ifs("save.txt");
std::string tmpx;
std::string tmpy;
//obstacle
Asteroid ast(window.getSize());
std::vector<Asteroid> asteroids;

//CHARGEMENT DE LA SAVE
if(ifs){
  ifs>>tmpx;
  score=std::stoi(tmpx);
  ifs>>tmpx;
  for(int i=std::stoi(tmpx);i<3;i++){
    Nav.degat();
  }
  ifs>>tmpx;
  Nav.cooldown=std::stoi(tmpx);
  ifs>>tmpx;
  Nav.invincibilite=std::stoi(tmpx);
  ifs>>tmpx;
  ifs>>tmpy;
  Nav.vsprite.setPosition(std::stoi(tmpx),std::stoi(tmpy));
  ifs>>tmpx;
  if(tmpx.compare("A")==0){
    ifs>>tmpx;
    ast.spawndelai=std::stoi(tmpx);
        ifs>>tmpx;
        ifs>>tmpy;
      while(tmpx.compare("/A")!=0){
        ast.astsprite.setPosition(std::stoi(tmpx),std::stoi(tmpy));
        asteroids.push_back(ast);
        ifs>>tmpx;
        ifs>>tmpy;
      }
  }
}

  while(window.isOpen()){
    //RESTART DE LA PARTIE
    if(Nav.vie==0 && Nav.invincibilite==-1){
          score=0;
          for(size_t i=0;i<asteroids.size();i++){
              asteroids.erase(asteroids.begin()+i);
          }
          for(size_t i=0;i<Nav.P2lasers.size();i++){
              Nav.P2lasers.erase(Nav.P2lasers.begin()+i);
          }
          for(size_t i=0;i<Nav.P1lasers.size();i++){
              Nav.P1lasers.erase(Nav.P1lasers.begin()+i);
          }
          for(int i=0;i<3;i++){
            Nav.vieGui[i].setTexture(Nav.heartbox);
          }
          if (!Nav.jtexture.loadFromFile("./image/jvaisseau.png"))
          {
            std::cerr << "impossible de charger la Texture" << std::endl;
          }
          Nav.vsprite.setTexture(Nav.jtexture);
          Nav.vsprite.setPosition((wscreen/2),(hscreen/2));
          Nav.vie=3;
    }
    //AFFICHAGE DU SCORE
    tmpx="votre score est: "+std::to_string(score);
    text.setString(tmpx);

    //On recupere les touches du clavier
    while (window.pollEvent(event))
    {
      InputHandler(event,window,Nav,lp1,lp2,&pause);
      if(pause==1){
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
          mouse_pos = sf::Mouse::getPosition(window);
        }
      }
    }

    if(pause==0){
    //UPDATE POSITIONS,SPAWN ET SUPRESSION DES SPRITES EN DEHORS DE L'ENCRAN
    Nav.outbound(wscreen,hscreen);

    if(ast.spawn(window)==1){
      asteroids.push_back(ast);
    }

    for(size_t i=0;i<asteroids.size();i++){
      asteroids[i].astsprite.move(0.f,5.f);
      if(Nav.vsprite.getGlobalBounds().intersects(asteroids[i].astsprite.getGlobalBounds()) && Nav.vie>0 && Nav.invincibilite==-1){
        asteroids.erase(asteroids.begin()+i);
        Nav.degat();

      }
      if(asteroids[i].astsprite.getPosition().x>window.getSize().x||asteroids[i].astsprite.getPosition().x<0 || asteroids[i].astsprite.getPosition().y<0 || asteroids[i].astsprite.getPosition().y>window.getSize().y){
          asteroids.erase(asteroids.begin()+i);
      }
    }


    for(size_t i=0; i< Nav.P1lasers.size();i++){
      Nav.P1lasers[i].bltsprite.move(0.f,-20.f);
      if(Nav.P1lasers[i].bltsprite.getPosition().x>window.getSize().x||Nav.P1lasers[i].bltsprite.getPosition().x<0 || Nav.P1lasers[i].bltsprite.getPosition().y<0 || Nav.P1lasers[i].bltsprite.getPosition().y>window.getSize().y){
          Nav.P1lasers.erase(Nav.P1lasers.begin()+i);
      }
      for(size_t k=0;k<asteroids.size();k++){
        if(Nav.P1lasers[i].bltsprite.getGlobalBounds().intersects(asteroids[k].astsprite.getGlobalBounds())){
          asteroids.erase(asteroids.begin()+k);
          Nav.P1lasers.erase(Nav.P1lasers.begin()+i);
          score=score+10;
          break;
        }
      }
    }


    for(size_t i=0; i< Nav.P2lasers.size();i++){
      Nav.P2lasers[i].bltsprite.move(Nav.P2lasers[i].currVelocity);
      if(Nav.P2lasers[i].bltsprite.getPosition().x>window.getSize().x||Nav.P2lasers[i].bltsprite.getPosition().x<0 || Nav.P2lasers[i].bltsprite.getPosition().y<0 || Nav.P2lasers[i].bltsprite.getPosition().y>window.getSize().y){
          Nav.P2lasers.erase(Nav.P2lasers.begin()+i);
      }
      for(size_t k=0;k<asteroids.size();k++){
        if(Nav.P2lasers[i].bltsprite.getGlobalBounds().intersects(asteroids[k].astsprite.getGlobalBounds())){
          asteroids.erase(asteroids.begin()+k);
          Nav.P2lasers.erase(Nav.P2lasers.begin()+i);
          score=score+10;
          break;
        }
      }
    }

  bg.Update(window,10.f);

  if(Nav.invincibilite!=-1 && Nav.invincibilite<100){
    Nav.invincibilite++;
  }else if(Nav.invincibilite==100){
    Nav.invincibilite=-1;
  }
  if(Nav.cooldown>0){
    Nav.cooldown--;
  }
}else{
  if(menu.startsprt.getGlobalBounds().contains(sf::Vector2f(mouse_pos))){
    pause=0;
    mouse_pos=sf::Vector2i(0,0);
  }
  if(menu.exitsprt.getGlobalBounds().contains(sf::Vector2f(mouse_pos))){


    //revenir au menu en sauvegardant
    std::ofstream ofs("save.txt",std::ios::trunc);
    ofs<<score<<std::endl;
    ofs<<Nav.vie<<std::endl;
    ofs<<Nav.cooldown<<std::endl;
    ofs<<Nav.invincibilite<<std::endl;
    ofs<<Nav.vsprite.getPosition().x<<std::endl;
    ofs<<Nav.vsprite.getPosition().y<<std::endl;

    if(!asteroids.empty()){
      ofs<<"A"<<std::endl;
      ofs<<ast.spawndelai<<std::endl;
      for(int i=0; i<asteroids.size();i++){
          ofs<< asteroids[i].astsprite.getPosition().x << std::endl;
          ofs<< asteroids[i].astsprite.getPosition().y << std::endl;
      }
      ofs<<"/A"<<std::endl;
    }

    return 2;
  }

}
  //DESSIN

  window.clear();
  bg.Render(window);
  if(Nav.invincibilite==-1 || (Nav.invincibilite%2)==0){
    window.draw(Nav.vsprite);
  }
  for(int i=0; i<3;i++){
    window.draw(Nav.vieGui[i]);
  }
  for(size_t i=0; i< Nav.P1lasers.size();i++){
    window.draw(Nav.P1lasers[i].bltsprite);
  }
  for(size_t i=0;i<asteroids.size();i++){
    window.draw(asteroids[i].astsprite);
  }

  for(size_t i=0; i< Nav.P2lasers.size();i++){
    window.draw(Nav.P2lasers[i].bltsprite);
  }
  window.draw(text);
  if(pause==1){
    window.draw(menu.popup);
    window.draw(menu.startsprt);
    window.draw(menu.exitsprt);
  }
  window.display();
  }
return 0;
}








void InputHandler(sf::Event event, sf::RenderWindow &window, Vaisseau &s, P1shoot b, P2shoot b2,int* pause){

  if(event.type==sf::Event::Closed){
      window.close();
    }
    if(event.type==sf::Event::KeyReleased){
      if(event.key.code==sf::Keyboard::Escape){
        if(*pause==0){
          *pause=1;
        }else{
          *pause=0;
        }
      }
    }
    if(s.vie>0 && *pause==0){
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Z) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
      s.vsprite.move(0,-5);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Q) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
        s.vsprite.move(-5,0);
      }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
      s.vsprite.move(0,5);
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
        s.vsprite.move(5,0);
    }
    if(event.type==sf::Event::KeyReleased){
      if(event.key.code==sf::Keyboard::Space){
        b.setpos(s.vsprite.getPosition());
        b.bltsprite.setPosition(b.bltsprite.getPosition().x-10,b.bltsprite.getPosition().y-100);
        s.P1lasers.push_back(b);
      }
    }
    if(sf::Mouse::isButtonPressed(sf::Mouse::Left) && s.cooldown==0){
      b2.playerCenter=sf::Vector2f(s.vsprite.getPosition().x,s.vsprite.getPosition().y);
      b2.mousePosWindow = sf::Vector2f(sf::Mouse::getPosition(window));
      b2.aimDir=b2.mousePosWindow-b2.playerCenter;
      b2.aimDirNorm = b2.aimDir/std::sqrt(std::pow(b2.aimDir.x,2.f)+std::pow(b2.aimDir.y,2.f));
      b2.bltsprite.setPosition(b2.playerCenter);
      b2.currVelocity=b2.aimDirNorm*b2.maxspeed;
      s.P2lasers.push_back(P2shoot(b2));
      s.cooldown=20;
    }
  }

}
