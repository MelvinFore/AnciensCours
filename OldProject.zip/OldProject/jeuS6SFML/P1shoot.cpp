#include "P1shoot.hpp"

P1shoot :: P1shoot(sf::Vector2f pos)
{
  if (!bltext.loadFromFile("./image/tire.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  bltsprite.setTexture(bltext);
  bltsprite.setPosition(pos);

}

void P1shoot::setpos(sf::Vector2f pos){
  this->bltsprite.setPosition(pos);
}
