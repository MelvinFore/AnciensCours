#include "Vaisseau.hpp"

Vaisseau :: Vaisseau()
{
  int hscreen=sf::VideoMode::getDesktopMode().height;
  int wscreen=sf::VideoMode::getDesktopMode().width;
  if (!jtexture.loadFromFile("./image/jvaisseau.png"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  if (!box.loadFromFile("./image/hpvide.PNG"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  if (!heartbox.loadFromFile("./image/hp.PNG"))
  {
    std::cerr << "impossible de charger la Texture" << std::endl;
  }
  for(int i=0;i<3;i++){
    vieGui[i].setTexture(heartbox);
    vieGui[i].setPosition((i*53)+3,0);
  }
  vsprite.setTexture(jtexture);
  vsprite.setOrigin(52,74);
  vsprite.setPosition(wscreen/2,hscreen/2);
  vie=3;
}

void Vaisseau :: degat(){
  this->vie=this->vie-1;
  this->vieGui[this->vie].setTexture(box);
  if(this->vie==0){
    if (!jtexture.loadFromFile("./image/explo1.png"))
    {
      std::cerr << "impossible de charger la Texture" << std::endl;
    }
    vsprite.setTexture(jtexture);
  }
  this->invincibilite=0;
}

void Vaisseau :: outbound(int w, int h){
  if(this->vsprite.getPosition().x<0.f){
    this->vsprite.setPosition(0.f+(this->vsprite.getTexture()->getSize().x/2.f),this->vsprite.getPosition().y);
  }else if(this->vsprite.getPosition().x>=w){
    this->vsprite.setPosition(w-(this->vsprite.getTexture()->getSize().x/2.f),this->vsprite.getPosition().y);
  }

  if(vsprite.getPosition().y<0.f){
    this->vsprite.setPosition(this->vsprite.getPosition().x,0.f+(this->vsprite.getTexture()->getSize().y/2.f));
  }else if(vsprite.getPosition().y>=h){
    this->vsprite.setPosition(this->vsprite.getPosition().x,h-(this->vsprite.getTexture()->getSize().y/2.f));
  }

}
